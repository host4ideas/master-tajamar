﻿namespace MvcNetCoreZapatillas.Models
{
    public class ModelPaginarZapatilla
    {
        public List<ImagenZapatilla> Imagenes { get; set; }
        public int NumeroRegistros { get; set; }
    }
}
