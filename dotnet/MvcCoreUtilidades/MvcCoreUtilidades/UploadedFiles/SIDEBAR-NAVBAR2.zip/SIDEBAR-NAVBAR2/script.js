let mql = window.matchMedia('(max-width: 768px)');
console.log("A: " + mql.matches)
if(!mql.matches){
    console.log("Adios: " + document.getElementById("sidebar"))
    document.getElementById("sidebar").classList.remove("-translate-x-full")
    document.getElementById("content").style.marginLeft = "249px"
}

