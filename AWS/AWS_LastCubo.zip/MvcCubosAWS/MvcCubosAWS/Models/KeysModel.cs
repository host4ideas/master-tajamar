﻿namespace MvcCubosAWS.Models {
    public class KeysModel {
        public string ApiUrl { set; get; }
    }
}
